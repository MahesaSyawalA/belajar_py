# nama : mahesa syawal abdurahman
# nim : 2403372
# kelas : 1 C

nilai = [90, 86, 57, 59, 95, 77, 67, 94, 82, 86];

print(f'urutan nilai siswa : {nilai}')

input_index = int(input('Masukan no urut siswa : '));
nilai_pilihan = nilai[input_index-1];

print(f'no urut siswa yang anda masukan {input_index} adalah : {nilai_pilihan}');





