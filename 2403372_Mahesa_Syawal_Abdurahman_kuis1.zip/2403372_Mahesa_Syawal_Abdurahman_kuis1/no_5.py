# nama : mahesa syawal abdurahman
# nim : 2403372
# kelas : 1 C

# dikonversi menjadi meter terlebih dahulu
Panjang = 8;
Lebar = 10;
Tinggi = 4;


rumus_luas = 2 * (Panjang * Tinggi) + 2 * (Lebar * Tinggi) 

print(f'total luasnya {rumus_luas} dengan total biaya : RP. { rumus_luas*520000}');