# nama : mahesa syawal abdurahman
# nim : 2403372
# kelas : 1 C

menit =  10;
detik = 48;

menit_ke_detik = menit * 60 ;

print (f'waktu yang pak rendi inginkan yaitu 10 menit 48 detik ketika di konversi ke detik : {detik + menit_ke_detik} detik');