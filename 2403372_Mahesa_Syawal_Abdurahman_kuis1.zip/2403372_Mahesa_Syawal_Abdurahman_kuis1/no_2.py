# nama : mahesa syawal abdurahman
# nim : 2403372
# kelas : 1 C

panjang = 80;
# lebarnya di konversi ke meter yaitu 100
lebar = 32;

keliling_persegi_panjang  = (panjang * lebar) * 2;

print(f'keliling dari lapangan tersebut : {keliling_persegi_panjang} m ');

rencana_lari = keliling_persegi_panjang * 5 ;
pemanasan = keliling_persegi_panjang * 2;
pendinginan = keliling_persegi_panjang * 2;

total = rencana_lari + pemanasan + pendinginan ;

print(f'jarak yang di tempuh oleh Bu Rinda dengan rencana lari sebanyak 5x, pendinginan 2x, dan pemanasan 2x = {total/1000}');






